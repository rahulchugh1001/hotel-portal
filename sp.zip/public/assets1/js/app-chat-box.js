$(function() {
	"use strict";

    new PerfectScrollbar('.chat-list');
    new PerfectScrollbar('.chat-content');


});